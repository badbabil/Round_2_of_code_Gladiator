#include <stdio.h>
#include <math.h>
void main()
{
    double age, k_remain, k_lost; //decalring variables for result ,remaning  and lost mass

    const double half_life = 5730.0; //declaring a const value for t. Carbon-14 has a half-life of 5730 years

    printf("How much carbon has been lost (0-100%%)? ");
    scanf("%lf", &k_lost); //taking input of lost mass percentage

    k_remain = 1.0 - (k_lost / 100.0);                 //calculating the remaning mass
    age = -(half_life / log10(2.0)) * log10(k_remain); //calculating the age[using log10() for avoiding inconsistancy]

    printf("\nThe object is %lf years old.\n", age);
}