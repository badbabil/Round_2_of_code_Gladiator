#include <graphics.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <dos.h>

int smile_emoji(int, int);
int sad_emoji(int, int);
int speechless_emoji(int, int);
int angry_emoji(int, int);
int cry_emoji(int, int);

void main()
{
   void *p;
   int emoji_option;
   int gd = DETECT, gm, emoji_area, tempV1, tempV2;
   initgraph(&gd, &gm, "C:\\turboc3\\bgi");

   printf(" Choose option for the emotion & press enter: \n 1. For Happiness\n 2. For cry_emojiing \n 3. For anger \n 4. For sad_emojiness \n 5. For speechless \n press Any other key to Exit. \n");

   scanf("%d", &emoji_option); // taking the input

   while (emoji_option != 0) //starting the program as a loop
   {

      int align_top = 75, align_left = 275;

      cleardevice();
      gotoxy(1, 1);

      printf(" Choose option for the emotion & press enter: \n 1. For Happiness\n 2. For crying \n 3. For anger \n 4. For sadness \n 5. For speechless \n press Any other key to Exit. \n");

      switch (emoji_option)
      {
      case 1:
         p = malloc(smile_emoji(align_left, align_top));
         break;
      case 2:
         p = malloc(cry_emoji(align_left, align_top));
         break;
      case 3:
         p = malloc(angry_emoji(align_left, align_top));
         break;
      case 4:
         p = malloc(sad_emoji(align_left, align_top));
         break;
      case 5:
         p = malloc(speechless_emoji(align_left, align_top));
         break;
      default:
         emoji_option = 0;
         continue;
      }

      while (!kbhit()) //until keyboard input is 1-6

      {
         tempV1 = 1 + (rand() % (588 - 50 + 1)) + 50;
         tempV2 = 1 + (rand() % (380 - 150 + 1)) + 150;

         getimage(align_left, align_top, align_left + 50, align_top + 50, p);
         putimage(align_left, align_top, p, XOR_PUT);
         putimage(tempV1, tempV2, p, XOR_PUT);
         delay(500);
         align_left = tempV1;
         align_top = tempV2;
      }
      emoji_option = getch() - '0'; // taking the input
      free(p);
   }

   printf("Good bye !\n");
   getch();
   closegraph();
}

int smile_emoji(int align_left, int align_top)
{

   setcolor(YELLOW);
   circle(300, 100, 24);
   setfillstyle(SOLID_FILL, YELLOW);
   floodfill(300, 100, YELLOW);

   // Set color of background to black
   setcolor(BLACK);
   setfillstyle(SOLID_FILL, BLACK);

   // Use fill ellipse for creating eyes
   fillellipse(294, 90, 2, 6);
   fillellipse(306, 90, 2, 6);

   // Use ellipse for creating mouth
   ellipse(300, 100, 205, 335, 20, 9);
   ellipse(300, 100, 205, 335, 20, 10);
   ellipse(300, 100, 205, 335, 20, 11);

   return imagesize(align_left, align_top, align_left + 50, align_top + 50);
}

int sad_emoji(int align_left, int align_top)
{
   setcolor(YELLOW);
   circle(300, 100, 24);
   setfillstyle(SOLID_FILL, YELLOW);
   floodfill(300, 100, YELLOW);

   // Set color of background to black
   setcolor(BLACK);
   setfillstyle(SOLID_FILL, BLACK);

   // Use fill ellipse for creating eyes
   fillellipse(294, 90, 2, 6);
   fillellipse(306, 90, 2, 6);

   // Use ellipse for creating mouth
   ellipse(300, 113, 360, 185, 10, 9);
   ellipse(300, 113, 360, 185, 10, 10);
   ellipse(300, 113, 360, 185, 10, 11);

   return imagesize(align_left, align_top, align_left + 50, align_top + 50);
}

int speechless_emoji(int align_left, int align_top)
{
   setcolor(YELLOW);
   circle(300, 100, 24);
   setfillstyle(SOLID_FILL, YELLOW);
   floodfill(300, 100, YELLOW);

   // Set color of background to black
   setcolor(BLACK);
   setfillstyle(SOLID_FILL, BLACK);

   // Use fill ellipse for creating eyes
   fillellipse(294, 90, 2, 6);
   fillellipse(306, 90, 2, 6);

   return imagesize(align_left, align_top, align_left + 50, align_top + 50);
}

int cry_emoji(int align_left, int align_top)
{

   setcolor(YELLOW);
   circle(300, 100, 24);
   setfillstyle(SOLID_FILL, YELLOW);
   floodfill(300, 100, YELLOW);

   // Set color of background to black
   setcolor(BLACK);
   setfillstyle(SOLID_FILL, BLACK);

   // Use fill ellipse for creating eyes
   fillellipse(294, 90, 2, 4);
   fillellipse(306, 90, 2, 4);

   // use fill ellipse for creating tears
   setcolor(BLUE);
   setfillstyle(SOLID_FILL, CYAN);
   fillellipse(294, 100, 2, 6);

   setcolor(BLUE);
   setfillstyle(SOLID_FILL, CYAN);
   fillellipse(306, 100, 2, 6);

   setcolor(BLACK);
   setfillstyle(SOLID_FILL, BLACK);

   // Use ellipse for creating mouth
   ellipse(300, 118, 360, 185, 10, 9);
   ellipse(300, 118, 360, 185, 10, 10);
   ellipse(300, 118, 360, 185, 10, 11);

   return imagesize(align_left, align_top, align_left + 50, align_top + 50);
}

int angry_emoji(int align_left, int align_top)
{
   setcolor(LIGHTRED);
   circle(300, 100, 24);

   setfillstyle(SOLID_FILL, LIGHTRED);
   floodfill(300, 100, LIGHTRED);

   // Set color of background to black
   setcolor(BLACK);
   setfillstyle(SOLID_FILL, BLACK);

   ellipse(292, 85, 360, 125, 5, 3); //align_left eyebrow
   ellipse(307, 85, 100, 200, 5, 3); //right eyebrow
   // Use fill ellipse for creating eyes
   fillellipse(296, 90, 2, 4);
   fillellipse(303, 90, 2, 4);

   // Use ellipse for creating mouth
   ellipse(300, 113, 360, 165, 10, 9);
   ellipse(300, 113, 360, 165, 10, 10);
   ellipse(300, 113, 360, 165, 10, 11);

   return imagesize(align_left, align_top, align_left + 50, align_top + 50);
}